<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('accounts', function (Blueprint $table) {

            $table->dropForeign([
                'customer_id'
            ]);

            $table->foreignId('customer_id')
                ->nullable()
                ->change();

            $table->foreign('customer_id')
                ->references('id')
                ->on('customers')
                ->nullOnDelete();

        });
    }


    public function down(): void
    {
        //
    }

};

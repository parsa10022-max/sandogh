@extends('layouts.app')

@section('title', 'مدیریت مشتریان')

@section('content')

    <div class="container-fluid">

        <x-page-header title="مدیریت مشتریان">

            <a
                href="{{ route('customers.create') }}"
                class="btn btn-primary">

                <i class="bi bi-plus-circle"></i>
                مشتری جدید
            </a>

        </x-page-header>

        {{-- Search --}}
        <x-search-box
            :action="route('customers.index')"
        />

        {{-- Table --}}
        <x-datatable.table>

            <div class="card-body p-0">

                <table class="table table-hover table-striped align-middle mb-0">

                    <thead class="table-dark">

                    <tr>

                        <th>کد</th>

                        <th>نام</th>

                        <th>کد ملی</th>

                        <th>موبایل</th>

                        <th>وضعیت</th>

                        <th width="120">عملیات</th>

                    </tr>

                    </thead>

                    <tbody>

                    @forelse($customers as $customer)

                        <tr>

                            <td>{{ $customer->customer_code }}</td>

                            <td>{{ $customer->full_name }}</td>

                            <td>{{ $customer->national_code }}</td>

                            <td>{{ $customer->mobile }}</td>

                            <td>

                                {{ $customer->status->label()}}

                            </td>

                            <td class="text-center">

                                <div class="d-flex justify-content-center gap-1">

                                    <x-action-buttons
                                        :show-route="route('customers.show', $customer)"
                                        :edit-route="route('customers.edit', $customer)"
                                        :delete-route="route('customers.destroy', $customer)"
                                    />

                                </div>

                            </td>

                        </tr>

                    @empty

                        <tr>

                            <td colspan="6"
                                class="text-center py-4">

                                مشتری ثبت نشده است.

                            </td>

                        </tr>

                    @endforelse

                    </tbody>

                </table>

            </div>

        </x-datatable.table>

        <x-pagination :items="$customers"/>
        {{-- Pagination --}}

    </div>

@endsection
